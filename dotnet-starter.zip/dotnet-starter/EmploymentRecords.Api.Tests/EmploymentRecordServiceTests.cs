using EmploymentRecords.Api.Data;
using EmploymentRecords.Api.Dtos;
using EmploymentRecords.Api.Services;
using Xunit;

namespace EmploymentRecords.Api.Tests;

public class EmploymentRecordServiceTests
{
    // Example test showing the pattern — candidates should add tests covering the
    // overlap/duplicate rule, validation failures, and not-found behavior at minimum.

    [Fact]
    public async Task CreateEmploymentRecordAsync_ReturnsRecordWithGeneratedId()
    {
        var repository = new InMemoryEmploymentRecordRepository();
        var service = new EmploymentRecordService(repository);

        var dto = new CreateEmploymentRecordDto
        {
            UserId = 8831,
            EmployerName = "Brightline Freight Co.",
            StartDate = new DateOnly(2022, 3, 1),
            EndDate = new DateOnly(2024, 6, 15),
            Source = "EMPLOYER_DIRECT"
        };

        var result = await service.CreateEmploymentRecordAsync(dto);

        Assert.True(result.Id > 0);
        Assert.Equal(dto.UserId, result.UserId);
        Assert.Equal(dto.EmployerName, result.EmployerName);
    }

    // TODO (candidate): add a test proving that a second, overlapping submission for the
    // same user/employer is flagged rather than silently created as a second ACTIVE record.

    // TODO (candidate): add a test for GetByIdAsync returning null/404 for an id that
    // doesn't exist.
}
