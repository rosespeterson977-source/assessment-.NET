# Employment Records API — Starter Project

This is the starter scaffold for the MyEmployment .NET/API Software Engineer take-home
practical exercise. Full instructions, requirements, and acceptance criteria are in
**Document 3 — Practical Coding Exercise**, provided alongside this project.

## Quick start

```bash
cd EmploymentRecords.Api
dotnet run
```

```bash
cd EmploymentRecords.Api.Tests
dotnet test
```

## What's already wired up

- A working ASP.NET Core Web API project targeting .NET 8 that builds and runs out of the box.
- `Models/EmploymentRecord.cs` — the persistence entity.
- `Dtos/` — starter request/response DTO shapes. Change these if your design calls for it.
- `Data/IEmploymentRecordRepository.cs` and an in-memory implementation — swap for SQLite or
  EF Core InMemory if you prefer; no real database server is required either way.
- `Services/IEmploymentRecordService.cs` — where the duplicate/overlap business rule belongs.
  It is intentionally left unimplemented (`// TODO`).
- `Controllers/EmploymentRecordsController.cs` — the three required routes are defined; their
  bodies are marked `// TODO`.
- A test project referencing xUnit, with one example test so you can see the pattern used.

## What you need to add

1. Your definition of "duplicate" (see Document 3) — write it down, then implement it in the
   service layer.
2. The actual logic behind the three endpoints.
3. Validation and structured error responses.
4. At least 3 unit tests beyond the example provided.
5. A short section at the top of this README (or a new `SOLUTION.md`) describing your approach,
   assumptions, and anything you'd do differently with more time.

You are not required to keep this exact structure — see Document 3 for details.
