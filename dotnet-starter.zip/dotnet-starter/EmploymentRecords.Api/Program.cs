using EmploymentRecords.Api.Data;
using EmploymentRecords.Api.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();

// Candidates: register your repository and service implementations here.
// An in-memory singleton repository is fine for this exercise.
builder.Services.AddSingleton<IEmploymentRecordRepository, InMemoryEmploymentRecordRepository>();
builder.Services.AddScoped<IEmploymentRecordService, EmploymentRecordService>();

var app = builder.Build();

// No HTTPS redirection configured — this is a local-only exercise with no
// launchSettings.json HTTPS profile, so redirecting would just log warnings.
app.MapControllers();

app.Run();

// Exposed so the test project's WebApplicationFactory<Program> can find this entry point.
public partial class Program { }
