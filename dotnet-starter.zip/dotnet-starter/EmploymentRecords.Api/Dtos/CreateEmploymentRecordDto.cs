namespace EmploymentRecords.Api.Dtos;

/// <summary>
/// Starter shape — add validation attributes (or a validation step in the service/controller)
/// as appropriate. Change fields/types if your design calls for it.
/// </summary>
public class CreateEmploymentRecordDto
{
    public int UserId { get; set; }
    public string EmployerName { get; set; } = string.Empty;
    public DateOnly StartDate { get; set; }
    public DateOnly? EndDate { get; set; }
    public string Source { get; set; } = string.Empty;
}
