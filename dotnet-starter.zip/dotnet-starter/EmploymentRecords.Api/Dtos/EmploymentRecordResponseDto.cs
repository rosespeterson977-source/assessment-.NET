namespace EmploymentRecords.Api.Dtos;

public class EmploymentRecordResponseDto
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public string EmployerName { get; set; } = string.Empty;
    public DateOnly StartDate { get; set; }
    public DateOnly? EndDate { get; set; }
    public string Source { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string? ReviewReason { get; set; }
}
