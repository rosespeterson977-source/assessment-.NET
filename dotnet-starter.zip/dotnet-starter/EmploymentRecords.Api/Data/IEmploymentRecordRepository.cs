using EmploymentRecords.Api.Models;

namespace EmploymentRecords.Api.Data;

public interface IEmploymentRecordRepository
{
    Task<EmploymentRecord> AddAsync(EmploymentRecord record, CancellationToken cancellationToken = default);

    Task<EmploymentRecord?> GetByIdAsync(int id, CancellationToken cancellationToken = default);

    Task<List<EmploymentRecord>> GetByUserIdAsync(int userId, CancellationToken cancellationToken = default);

    /// <summary>
    /// Candidates: implement whatever query shape your overlap-detection logic needs.
    /// This starter signature is a suggestion, not a requirement.
    /// </summary>
    Task<List<EmploymentRecord>> GetByUserAndEmployerAsync(int userId, string employerName, CancellationToken cancellationToken = default);
}
