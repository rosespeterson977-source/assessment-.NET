using System.Collections.Concurrent;
using EmploymentRecords.Api.Models;

namespace EmploymentRecords.Api.Data;

/// <summary>
/// Minimal in-memory repository so the project runs with no external dependencies.
/// Swap for SQLite or EF Core's InMemory provider if you'd rather — neither is required.
/// </summary>
public class InMemoryEmploymentRecordRepository : IEmploymentRecordRepository
{
    private readonly ConcurrentDictionary<int, EmploymentRecord> _records = new();
    private int _nextId = 1000;

    public Task<EmploymentRecord> AddAsync(EmploymentRecord record, CancellationToken cancellationToken = default)
    {
        record.Id = Interlocked.Increment(ref _nextId);
        record.CreatedDate = DateTime.UtcNow;
        _records[record.Id] = record;
        return Task.FromResult(record);
    }

    public Task<EmploymentRecord?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        _records.TryGetValue(id, out var record);
        return Task.FromResult(record);
    }

    public Task<List<EmploymentRecord>> GetByUserIdAsync(int userId, CancellationToken cancellationToken = default)
    {
        var results = _records.Values.Where(r => r.UserId == userId).ToList();
        return Task.FromResult(results);
    }

    public Task<List<EmploymentRecord>> GetByUserAndEmployerAsync(int userId, string employerName, CancellationToken cancellationToken = default)
    {
        // Candidates: decide how strict this match should be (case sensitivity, whitespace,
        // punctuation) as part of your duplicate definition.
        var results = _records.Values
            .Where(r => r.UserId == userId && r.EmployerName == employerName)
            .ToList();
        return Task.FromResult(results);
    }
}
