using EmploymentRecords.Api.Dtos;
using EmploymentRecords.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace EmploymentRecords.Api.Controllers;

[ApiController]
[Route("api")]
public class EmploymentRecordsController : ControllerBase
{
    private readonly IEmploymentRecordService _service;

    public EmploymentRecordsController(IEmploymentRecordService service)
    {
        _service = service;
    }

    [HttpPost("employment-records")]
    public async Task<IActionResult> Create([FromBody] CreateEmploymentRecordDto dto, CancellationToken cancellationToken)
    {
        // TODO (candidate): validate the input and return a structured 400 on failure.
        var created = await _service.CreateEmploymentRecordAsync(dto, cancellationToken);

        // TODO (candidate): decide on the right status code for the "flagged for review" case
        // (200/202/409 are all defensible — justify your choice in the README).
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
    }

    [HttpGet("employment-records/{id:int}")]
    public async Task<IActionResult> GetById(int id, CancellationToken cancellationToken)
    {
        var record = await _service.GetByIdAsync(id, cancellationToken);

        // TODO (candidate): this already returns 404 correctly for a missing record —
        // confirm that's what you want, and that no raw entity/exception leaks through.
        if (record is null)
        {
            return NotFound();
        }

        return Ok(record);
    }

    [HttpGet("users/{userId:int}/employment-records")]
    public async Task<IActionResult> GetByUserId(int userId, CancellationToken cancellationToken)
    {
        var records = await _service.GetByUserIdAsync(userId, cancellationToken);
        return Ok(records); // an empty list for a user with none is expected, not an error
    }
}
