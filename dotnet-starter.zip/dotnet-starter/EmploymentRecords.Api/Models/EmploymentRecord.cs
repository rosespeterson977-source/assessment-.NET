namespace EmploymentRecords.Api.Models;

/// <summary>
/// Persistence entity. Do not return this type directly from the API — map it to a
/// response DTO (see Dtos/EmploymentRecordResponseDto.cs).
/// </summary>
public class EmploymentRecord
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public string EmployerName { get; set; } = string.Empty;
    public DateOnly StartDate { get; set; }
    public DateOnly? EndDate { get; set; }
    public string Source { get; set; } = string.Empty;

    /// <summary>
    /// ACTIVE for a normal record, PENDING_REVIEW for one flagged by the
    /// duplicate/overlap business rule. Candidates: feel free to model this
    /// differently (e.g., a separate table/collection) if you prefer.
    /// </summary>
    public string Status { get; set; } = "ACTIVE";

    public string? ReviewReason { get; set; }

    public DateTime CreatedDate { get; set; }
}
