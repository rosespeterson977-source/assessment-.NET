using EmploymentRecords.Api.Dtos;

namespace EmploymentRecords.Api.Services;

public interface IEmploymentRecordService
{
    Task<EmploymentRecordResponseDto> CreateEmploymentRecordAsync(CreateEmploymentRecordDto dto, CancellationToken cancellationToken = default);

    Task<EmploymentRecordResponseDto?> GetByIdAsync(int id, CancellationToken cancellationToken = default);

    Task<List<EmploymentRecordResponseDto>> GetByUserIdAsync(int userId, CancellationToken cancellationToken = default);
}
