using EmploymentRecords.Api.Data;
using EmploymentRecords.Api.Dtos;
using EmploymentRecords.Api.Models;

namespace EmploymentRecords.Api.Services;

public class EmploymentRecordService : IEmploymentRecordService
{
    private readonly IEmploymentRecordRepository _repository;

    public EmploymentRecordService(IEmploymentRecordRepository repository)
    {
        _repository = repository;
    }

    public async Task<EmploymentRecordResponseDto> CreateEmploymentRecordAsync(CreateEmploymentRecordDto dto, CancellationToken cancellationToken = default)
    {
        // TODO (candidate): validate dto (required fields, StartDate <= EndDate, etc.)
        // and return/throw something the controller can turn into a 400 for invalid input.

        // TODO (candidate): implement the duplicate/overlap business rule described in
        // Document 3 before this record is treated as ACTIVE. Write down what you consider
        // a duplicate (see the README), then implement it here using
        // _repository.GetByUserAndEmployerAsync(...) or your own query shape.

        var record = new EmploymentRecord
        {
            UserId = dto.UserId,
            EmployerName = dto.EmployerName,
            StartDate = dto.StartDate,
            EndDate = dto.EndDate,
            Source = dto.Source,
            Status = "ACTIVE" // TODO: set to "PENDING_REVIEW" (with a ReviewReason) when appropriate
        };

        var saved = await _repository.AddAsync(record, cancellationToken);

        return MapToDto(saved);
    }

    public async Task<EmploymentRecordResponseDto?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        var record = await _repository.GetByIdAsync(id, cancellationToken);
        return record is null ? null : MapToDto(record);
    }

    public async Task<List<EmploymentRecordResponseDto>> GetByUserIdAsync(int userId, CancellationToken cancellationToken = default)
    {
        var records = await _repository.GetByUserIdAsync(userId, cancellationToken);
        return records.Select(MapToDto).ToList();
    }

    private static EmploymentRecordResponseDto MapToDto(EmploymentRecord record)
    {
        return new EmploymentRecordResponseDto
        {
            Id = record.Id,
            UserId = record.UserId,
            EmployerName = record.EmployerName,
            StartDate = record.StartDate,
            EndDate = record.EndDate,
            Source = record.Source,
            Status = record.Status,
            ReviewReason = record.ReviewReason
        };
    }
}
